package TestCases;

import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import Pages.Index;
import Pages.Authintication;


public class LoginTCs {

    WebDriver driver;
	String baseURL="http://automationpractice.com/index.php";
	String PathDriver="E:\\Backup 13-3-2022\\Selenium\\chromedriver.exe";
	
	@BeforeMethod
	public void lunchBrowser() {					
		System.setProperty("webdriver.chrome.driver",PathDriver);
	driver = new ChromeDriver();
		driver.navigate().to(baseURL);
		driver.manage().window().setSize(new Dimension(1024, 768));
	}

	// Verify with Valid Data
	@Test(priority=1)
	public void loginTC1() {		
		//Creating objects of Index page
		Index indx = new Index(driver);
		Authintication Auth = new Authintication(driver);
		indx.clickSignIN();
		Auth.Entermaillogin("saraShawry@yopmail.com");
		Auth.Enterpasslogin("asdf12345");
		Auth.clicklogin();
		indx.PerformWait(25);
		String Actual ="http://automationpractice.com/index.php?controller=my-account";
		String Expected=driver.getCurrentUrl();
		Assert.assertEquals(Actual, Expected);
		
	}
	

	// Verify with inValid Data
	@Test(priority=2)
	public void loginTC2() {
		Index indx = new Index(driver);
		Authintication Auth = new Authintication(driver);
		indx.clickSignIN();
		Auth.Entermaillogin("saraShawry@yopmail.com");
		Auth.Enterpasslogin("asdf12345");
		Auth.clicklogin();
		indx.PerformWait(25);
		String Actual ="http://automationpractice.com/index.php?controller=my-account";
		String Expected=driver.getCurrentUrl();
		String assertionError = null;
		try {
			Assert.assertEquals(Actual, Expected);
        }
		
        catch (AssertionError ae) {
            assertionError = ae.toString();
        }
		
		System.out.println("Test Failed"+""+assertionError);

	}

	// Verify with Blank TextBoxes
	@Test(priority=3)
	public void loginTC3() {
		Index indx = new Index(driver);
		Authintication Auth = new Authintication(driver);
		indx.clickSignIN();
		Auth.Entermaillogin("");
		Auth.Enterpasslogin("");
		Auth.clicklogin();
		indx.PerformWait(25);
		String Actual ="http://automationpractice.com/index.php?controller=my-account";
		String Expected=driver.getCurrentUrl();
		String assertionError = null;
		try {
			Assert.assertEquals(Actual, Expected);
        }
		
        catch (AssertionError ae) {
            assertionError = ae.toString();
        }
		
		System.out.println("Test Failed"+""+assertionError);
		
	}
	
	
	@AfterMethod
	public void AfterTest() {
		driver.close();
	}


}
