package TestCases;

import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import Pages.Authintication;
import Pages.Index;
import Pages.MyAccount;

public class AddProductTCs {
	 WebDriver driver;
		String baseURL="http://automationpractice.com/index.php";
		String PathDriver="E:\\Backup 13-3-2022\\Selenium\\chromedriver.exe";
		
		@BeforeMethod
		public void lunchBrowser() {					
			System.setProperty("webdriver.chrome.driver",PathDriver);
		driver = new ChromeDriver();
			driver.navigate().to(baseURL);
			driver.manage().window().setSize(new Dimension(1024, 768));
		}
		
		
		@Test(priority=1)
		public void AddProductToCartTC1() {		
			//Creating objects of Index page
			Index indx = new Index(driver);
			Authintication Auth = new Authintication(driver);
			indx.clickSignIN();
			Auth.Entermaillogin("saraShawry@yopmail.com");
			Auth.Enterpasslogin("asdf12345");
			Auth.clicklogin();
			indx.PerformWait(20);
			String URL=driver.getCurrentUrl();
			driver.get(URL);
			MyAccount Acc= new MyAccount(driver);
			indx.PerformWait(20);
			Acc.PerformHovertoWomen();
				
		}
		
		@AfterMethod
		public void AfterTest() {
			driver.close();
		}

}
