package TestCases;


import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import Pages.Index;
import Pages.Authintication;
import Pages.Register;

public class RegisterTC {

	    WebDriver driver;
		String baseURL="http://automationpractice.com/index.php";
		String PathDriver="E:\\Backup 13-3-2022\\Selenium\\chromedriver.exe";
	      
		
		
	@BeforeMethod
	public void lunchBrowser() {					
		System.setProperty("webdriver.chrome.driver",PathDriver);
	driver = new ChromeDriver();
		driver.navigate().to(baseURL);		
		driver.manage().window().setSize(new Dimension(1024, 768));
	}

			
	
	@Test(priority=1)
	public void RegisterAccountTC1() {
	    //Creating object of Index page
		Index indx = new Index(driver);
		//Creating object of Authentination
		Authintication Auth = new Authintication(driver);
		//Creating object of Register
		//Register Reg = new Register(driver);
		indx.clickSignIN();
		Auth.enterMail("sss@yopmail.com");
		Auth.ClickButtonCreate();
		indx.PerformWait(30);
		boolean result=Auth.ErrVisiable();
		if(!result)
		Assert.assertEquals(true, result);
		else System.out.println("Error Msg appear , Mail is frequent");
	}
	
	
	@Test(priority=2)
	public void RegisterAccountTC2() {
	    //Creating object of Index page
		Index indx = new Index(driver);
		//Creating object of Authentination
		Authintication Auth = new Authintication(driver);
		indx.clickSignIN();
		Auth.enterMail("saraShawry@yopmail.com");
		Auth.ClickButtonCreate();
		indx.PerformWait(30);
		//Creating object of Register
		Register Reg = new Register(driver);
		Reg.Gender();
		Reg.UserName("Sara", "Shawry");
		Reg.Password("asdf12345");
		Reg.Date();
		indx.PerformWait(20);
		indx.Scrolldown();
		indx.PerformWait(20);
		Reg.FillData();
		indx.PerformWait(20);
		indx.Scrolldown();
		Reg.FillData2();
		Reg.ClickSubmit();
	}
	
	
	
	@AfterMethod
	public void AfterTest() {
		driver.close();
	}

	
	
	
	
}
