package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

public class Register {

	WebDriver driver;
	
	public Register(WebDriver driver) {
		this.driver = driver;
	}
	
	By Gender = By.id("id_gender2");
	By Fname = By.id("customer_firstname");
	By Lname = By.id("customer_lastname");
	By Password = By.id("passwd");
	
	By Address = By.id("address1");
	By City = By.id("city");
	By ZipCode = By.id("postcode");
	By Phone = By.id("phone_mobile");
	By Address2 = By.id("alias");
	By SubmitRegister = By.id("submitAccount");

	// handeling Radio button
	public void Gender() {
		driver.findElement(Gender).click();
	}

	// Method to enter Fullname
	public void UserName(String FN, String LN) {
		driver.findElement(Fname).sendKeys(FN);
		driver.findElement(Lname).sendKeys(LN);
	}

	// Method to enter Paswword
	public void Password(String Pass) {
		driver.findElement(Password).sendKeys(Pass);
	}

	// Method to fill the Rest of form data
	public void FillData() {
		driver.findElement(Address).sendKeys("12 st Ahram , cairo ");
		driver.findElement(City).sendKeys("cairo ");
		State();
		driver.findElement(ZipCode).sendKeys("12543");
	}

	public void FillData2() {
		driver.findElement(Phone).sendKeys("0110000111");
		driver.findElement(Address2).sendKeys("");
	}

	// Method to handel Date
	public void Date() {
		Select Day = new Select(driver.findElement(By.id("days")));
		Select Month = new Select(driver.findElement(By.id("months")));
		Select Year = new Select(driver.findElement(By.id("years")));
		Day.selectByIndex(1);
		Month.selectByIndex(3);
		Year.selectByValue("1997");
	}

	// Method to handel State
	public void State() {

		Select State = new Select(driver.findElement(By.id("id_state")));
		State.selectByIndex(1);
	}

	// click Submit click to register account
	public void ClickSubmit() {
		driver.findElement(SubmitRegister).click();
	}

	

}
