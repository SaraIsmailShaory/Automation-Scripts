package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
public class Authintication {
	WebDriver driver;

	public Authintication(WebDriver driver) {
		this.driver = driver;
	}

	// Attributes for the Create Account
	By EmailTB = By.id("email_create");
	By CreateBTN = By.id("SubmitCreate");
	By ExpectedErrMSGDiv = By.xpath("//div[contains(@class,'alert alert-danger')]");

	// Attributes for the login
	By Emaillogin = By.id("email");
	By Password = By.id("passwd");
	By LoginBTN = By.id("SubmitLogin");

	// Methods For Create account
	public void enterMail(String Mail) {
		driver.findElement(EmailTB).sendKeys(Mail);
	}

	public void ClickButtonCreate() {
		driver.findElement(CreateBTN).click();
	}

	public Boolean ErrVisiable() {
		if (driver.findElement(ExpectedErrMSGDiv).isEnabled()) {
			return true;
		} else
			return false;
	}

	// Methods For login to an account
	public void Entermaillogin(String Mail) {
		driver.findElement(Emaillogin).sendKeys(Mail);
	}

	public void Enterpasslogin(String pass) {
		driver.findElement(Password).sendKeys(pass);
	}

	public void clicklogin() {
		driver.findElement(LoginBTN).click();
	}
	
	
}
