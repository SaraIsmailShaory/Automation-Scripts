package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;


public class MyAccount {
WebDriver driver;
	public MyAccount(WebDriver driver) {
          this.driver = driver;
	}

	
    
    
    // Handel Hover to an Item to Women Category
	public void PerformHovertoWomen() {		

		WebElement WomenLink= this.driver.findElement(By.xpath("/html/body/div/div[1]/header/div[3]/div/div/div[6]/ul/li[1]/a"));		
		Actions actions = new Actions(driver);
		actions.moveToElement(WomenLink);
		WebElement BlouseSubmenu= this.driver.findElement(By.xpath("//*[@id=\"block_top_menu\"]/ul/li[1]/ul/li[1]/ul/li[2]/a"));
		actions.moveToElement(BlouseSubmenu);
		actions.click().build().perform();
		Index indx=new Index(this.driver);
		indx.PerformWait(25);
		indx.Scrolldown();
		WebElement Blouse= this.driver.findElement(By.xpath("/html/body/div/div[2]/div/div[3]/div[2]/ul/li/div/div[2]/h5/a"));		
		actions.moveToElement(Blouse);
		WebElement AddCartbtn= this.driver.findElement(By.xpath("//*[@id=\"center_column\"]/ul/li/div/div[2]/div[2]/a[1]"));
		actions.moveToElement(AddCartbtn);
		actions.click().build().perform();
		indx.PerformWait(30);
		driver.findElement(By.xpath("//*[@id=\"layer_cart\"]/div[1]/div[2]/div[4]/a")).click();
		CheckoutProcess();
	}
	
	public void CheckoutProcess() {
		Index indx=new Index(this.driver);
		indx.PerformWait(20);
		indx.Scrolldown();
		indx.Scrolldown();				
		String TotalVal=driver.findElement(By.id("total_price_container")).getText();
		System.out.println(TotalVal);
		driver.findElement(By.xpath("//*[@id=\"center_column\"]/p[2]/a[1]")).click();
		indx.PerformWait(20);
		indx.Scrolldown();
		indx.Scrolldown();
		driver.findElement(By.xpath("//*[@id=\"center_column\"]/form/p/button")).click();
		indx.PerformWait(20);
		indx.Scrolldown();
		indx.Scrolldown();
		driver.findElement(By.id("cgv")).click();
		driver.findElement(By.xpath("//*[@id=\"form\"]/p/button")).click();
		PaymentProcess(TotalVal);
		
	}
	
	
	public void PaymentProcess(String Val) {
		
	Index indx=new Index(this.driver);
	indx.PerformWait(25);
	indx.Scrolldown();
	driver.findElement(By.xpath("//*[@id=\"HOOK_PAYMENT\"]/div[1]/div/p/a")).click();
	indx.PerformWait(25);
	indx.Scrolldown();
	driver.findElement(By.xpath("//*[@id=\"cart_navigation\"]/button")).click();
	indx.PerformWait(25);
	indx.Scrolldown();
	driver.findElement(By.xpath("//*[@id=\"center_column\"]/p/a")).click();
	VerifyOrder(Val);
	}
	
	public void VerifyOrder(String Val) {
		
		Index indx=new Index(this.driver);
		indx.PerformWait(25);
		indx.Scrolldown();
		String ExpectedVal=driver.findElement(By.xpath("//*[@id=\"order-list\"]/tbody/tr[1]/td[3]")).getText();
		System.out.println(ExpectedVal);
		String assertionError = "Error Happened";
		try {
			Assert.assertEquals(Val, ExpectedVal);
        }
		
        catch (AssertionError ae) {
            assertionError = ae.toString();

    		System.out.println("Test Failed"+""+assertionError);	
        }
			
	}
	
}
