package Pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;

public class Index {
WebDriver driver;
	
	public Index(WebDriver driver) {
          this.driver = driver;
	}
	
	By SignInLink= By.xpath("//*[@id=\"header\"]/div[2]/div/div/nav/div[1]/a");
	
	
	
	//Method to click on AUTHENTICATION Link
		public void clickSignIN() {
			driver.findElement(SignInLink).click();
		}
		
		
		
	// public Function that can be used all over the Project so included in the main Class
		public void Scrolldown() {
			// to perform Scroll down application using Selenium
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollBy(0,350)", "");
		}
		
		public void PerformWait(int x) {
			driver.manage().timeouts().implicitlyWait(x, TimeUnit.SECONDS);	
		}
}
